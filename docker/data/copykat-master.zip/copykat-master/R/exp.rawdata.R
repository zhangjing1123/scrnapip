#' raw UMI count matrix.
#'
#' An example dataset containing the UMI counts for 300 single cells.
#'
#' @format A data matrix with 33694 rows (genes) and 1097 columns (single cell names):
"exp.rawdata"
